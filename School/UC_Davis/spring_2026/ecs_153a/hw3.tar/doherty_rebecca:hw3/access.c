#include <stdio.h>      
#include <stdlib.h>     
#include <string.h>     
#include <sys/stat.h>   // stat()
#include <pwd.h>        // getpwnam, getpwuid
#include <grp.h>        // getgrnam, getgrgid
#include <stdbool.h>

// function that prints output line
void result_print(char *filename, bool gflag, char *display_name, uid_t user_UID, gid_t user_GID, int dir_or_file, int read, int write, int execute){
    // make a case for each format possibility
    // who is being checked?

    if(display_name != NULL && gflag == true){
        printf("Members of the group %s (GID %d) ", display_name, user_GID);
    }
    else if(display_name == NULL && gflag == true){
        printf("Members of the group with GID %d ", user_GID);
    }
    else if(display_name != NULL && gflag == false){
        printf("The user %s (UID %d) ", display_name, user_UID);
    }
    else if(display_name == NULL && gflag == false){
        printf("The user with UID %d ", user_UID);
    }
        
    int permissions = 0;
    // if file what are their permissions
    // dicrectory has different output
    if(read) permissions++;
    if(write) permissions++;
    if(execute) permissions++;

    if(permissions == 0){
        if(dir_or_file == 0){
            printf("can do nothing with the directory %s\n", filename);
        }
        else{
            printf("can do nothing with the file %s\n", filename);
        }
    }
    else if(permissions == 1){
        if(read){
            // print read permission
            if(dir_or_file == 0){
                printf("can list the contents of the directory %s\n", filename);
            }
            else{
                printf("can read the file %s\n", filename);
            }
        }
        else if(write){
            // print write permission
            if(dir_or_file == 0){
                printf("can modify the directory %s\n", filename);
            }
            else{
                printf("can write the file %s\n", filename);
            }
        }
        else if(execute){
            // print execute permission
            if(dir_or_file == 0){
                printf("can search the directory %s\n", filename);
            }
            else{
                printf("can execute the file %s\n", filename);
            }
        }
    }
    else if(permissions == 2){
        if(read && write){
            // print read and write
            if(dir_or_file == 0){
                printf("can list the contents of and modify the directory %s\n", filename);
            }
            else{
                printf("can read and write the file %s\n", filename);
            }

        }
        else if(read && execute){
            // print read and execute
            if(dir_or_file == 0){
                printf("can list the contents of and search the directory %s\n", filename);
            }
            else{
                printf("can read and execute the file %s\n", filename);
            }

        }
        else if(write && execute){
            // print write and execute
            if(dir_or_file == 0){
                printf("can modify and search the directory %s\n", filename);
            }
            else{
                printf("can write and execute the file %s\n", filename);
            }
        }
    }
    else if(permissions == 3){
        if(dir_or_file == 0){
            printf("can list the contents of, modify, and search the directory %s\n", filename);
        }
        else{
            printf("can read, write, and execute the file %s\n", filename);
        }
    }
}

int main(int argc, char *argv[]) {

    // parse arguments
    // check argc first in case there are no arguments
    if(argc == 1){
        fprintf(stderr, "usage: %s [ -g ] name file1 ...\n", argv[0]);
        exit(1);
    }

    // also check for cases if missing one or more of the arguments
    // use arg[1-n] to loop through arguments like -g flag and file name

    // get -g from arg[1]
    bool gflag = false;
    // name point to argv sinc argv stays valid for whole program
    char *name;
    int filename_index;
    uid_t user_UID = -1;
    gid_t user_GID = -1;
    char *display_name;

    // look up user
    // yes -g flag
    if (strcmp(argv[1], "-g") == 0) {
        // presence of -g flag means minimum arguments is 4
        if(argc < 3){
            fprintf(stderr, "usage: %s [ -g ] name file1 ...\n", argv[0]);
            exit(1);
        }
        gflag = true;
        name = argv[2];
        filename_index = 3;

        // check numeric or name
        if (sscanf(name, "%d", &user_GID) == 1) {
            // convert the string to a number
        } else {
            // look up by name using getpwnam()
            // getpwnam returns UID and username
            struct group *g = getgrnam(name);
            // what happens if there is no group??
            if(g == NULL){
                fprintf(stderr, "%s: no such group\n", name);
                exit(1);
            }
            user_GID = g -> gr_gid;
        }

        // get username and groupname here
        struct group *g2 = getgrgid(user_GID);
        if(g2 != NULL){
            // name exists
            display_name = g2->gr_name;
        } else {
            // no name for this GID
            display_name = NULL;
        }
    }
    // no -g flag
    else{
        name = argv[1];
        filename_index = 2;
        if (sscanf(name, "%d", &user_UID) == 1) {
            // convert the string to a number
            struct passwd *p = getpwuid(user_UID);
            if(p != NULL){
                user_GID = p->pw_gid;
            }
        } else {
            // look up by name using getpwnam()
            // getpwnam returns UID and username
            struct passwd *p = getpwnam(name);
            // no UID?? so user does not exist
            if (p == NULL) {
                fprintf(stderr, "%s: no such user\n", name);
                exit(1);
            }
            user_UID = p -> pw_uid;
            user_GID = p -> pw_gid;
        }
        //get uername and groupname here?
        struct passwd *p2 = getpwuid(user_UID);
        if(p2 != NULL){
            // name exists
            display_name = p2->pw_name;
        } else {
            // no name for this UID
            display_name = NULL;
        }
    }

    // check if file or directory given
    if(filename_index >= argc){
        fprintf(stderr, "%s: need at least one file or directory!\n", argv[0]);
        exit(1);
    }

    // loop over each file (cuz there may be multiple)
    for (int i = filename_index; i < argc; i++) {
        // stat() returns file info
        // https://pubs.opengroup.org/onlinepubs/7908799/xsh/sysstat.h.html
        uid_t owner_UID;
        gid_t owner_GID;
        mode_t mode;
        struct stat file_info;
        // default permissions
        int read = 0;
        int write = 0;
        int execute = 0;
        int dir_or_file = -1; // dir = 0 and file = 1

        if((stat(argv[i], &file_info)) == -1){
            perror(argv[i]);
            continue;  // next file
        }

        owner_UID = file_info.st_uid;
        owner_GID = file_info.st_gid;
        mode = file_info.st_mode;

        // file or directory
        if((mode & 0170000) == 0040000){  // directory
            dir_or_file = 0;
        }
        if((mode & 0170000) == 0100000){  // regular file
            dir_or_file = 1;
        }

        // root user case
        if(!gflag && user_UID == 0){
            read = 1;
            write = 1;
            execute = 1;
        }
        // from GID
        else if(gflag == true){
            // group permissions
            if(user_GID == owner_GID){
                read = mode & 0040;  // group can read
                write = mode & 0020;  // group can write
                execute = mode & 0010;  // group can execute
            }

            // other permissions if not in group or owner
            else{
                read = mode & 0004;  // other can read
                write = mode & 0002;  // other can write
                execute = mode & 0001;  // other can execute
            }

            
        }
        // from UID/name
        else{
            // owner permissions
            if(user_UID == owner_UID){
                read = mode & 0400;  // owner can read
                write = mode & 0200;  // owner can write
                execute = mode & 0100;  // owner can execute
            }

            // group permissions
            else if(user_GID == owner_GID){
                read = mode & 0040;  // group can read
                write = mode & 0020;  // group can write
                execute = mode & 0010;  // group can execute
            }

            // other permissions if not in group or owner
            else{
                read = mode & 0004;  // other can read
                write = mode & 0002;  // other can write
                execute = mode & 0001;  // other can execute
            }
            
        }
        result_print(argv[i], gflag, display_name, user_UID, user_GID, dir_or_file, read, write, execute);
    }

    return 0;
}